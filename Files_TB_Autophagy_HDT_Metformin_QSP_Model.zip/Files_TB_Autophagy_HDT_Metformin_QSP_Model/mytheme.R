my_theme<-function()
{
  theme_bw() +
    theme(axis.title.y = element_text(colour = 'black', size = 10, face="bold"))+
    theme(axis.text.y = element_text(size = 8,colour = 'black'))+
    theme(axis.title.x = element_text(colour = 'black', size = 10, face="bold"))+
    theme(axis.text.x = element_text(size = 8,colour = 'black'))+
    theme(plot.title = element_text(lineheight=.8, face="bold"))+
    theme(legend.position="bottom")+
    theme(legend.title=element_blank())+
    theme(legend.text = element_text(colour="black", size = 10, face = "bold")) +
    theme(strip.text = element_text(colour = 'black', size = 10, face="bold")) 
}