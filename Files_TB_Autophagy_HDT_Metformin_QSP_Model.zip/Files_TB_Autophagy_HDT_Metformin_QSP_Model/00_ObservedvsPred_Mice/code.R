
mod <- RxODE({
  
#Metformin mPBPK 
#Optimized some parameters (see S1) 
#Codes adapted from Jermain 2020
 ka = ka*24 ;
 CL = CL*24 ;
 Qco = Qco*24 ;
  d/dt(metdepot) = -ka*metdepot ;
  d/dt(metcent) = ka*metdepot -(CL/VpMET)*metcent + metlung*Qco/(Vl*Kplung) - metcent*Qco/VpMET + 
    metoth*Qco*FRC/(Voth*Kpoth) - metcent*Qco*FRC/VpMET ;
  d/dt(metlung) = metcent*Qco/VpMET - metlung*Qco/(Vl*Kplung) ;
  d/dt(metoth) = metcent*Qco*FRC/VpMET - metoth*Qco*FRC/(Voth*Kpoth)  ;
  CpMET = metcent/VpMET       ; 
  ClMET = metlung/Vl       ; 
  MET = ClMET*1000/129 ; # mg/L to umol/L

 ######## Mtb infection and autophagy
    A19 = A191 ;
    A20 = A201 ;
    
    if(t>=21) {
      A19=A192 ;
      A20=A202 ;
    } 
    
    #AKT3 gene fold change (infected/uninfected) = 1.38 #Singhal 2014
    if(Bi>=1) {MTBY=1 ;} else {MTBY = 0 ;} 
    if(MTBY==1) {AKT3FC = 1.38 ;} else {AKT3FC = 1;}
    
    mtor = mTORC1_pS2448 ;
    
    autop = 100 - (mtor*Smtorauto/(mtor+S50torauto))   ;
    
    METeff = (1 - (MET*EMMET/(E50MET + MET)))  ;
    
    k2stim = SLPk2autop*autop/30 ; #min autophagy 30
    
    ######## Sonntag 2012 Model ##########
    reaction_1 = P1*IR_beta*Insulin      ;
    reaction_2 = P2 * IR_beta_pY1146     ;
    reaction_3 = P3 * IR_beta_refractory ;
    reaction_4 = P4*IRS1*IR_beta_pY1146  ;
    reaction_5 = P5*IRS1_p*p70S6K_pT389   ;
    reaction_6 = P6 * IRS1_pS636          ;
    reaction_7 = P7*AMPK*IRS1_p   ;
    reaction_8 = P8 * AMPK_pT172       ;
    reaction_9 = P9 * Akt_pT308            ;
    reaction_10 = P10 * Akt_pS473          ;
    reaction_11 = P11*Akt_S473*mTORC2_pS2481*IRS1_p*AKT3FC   ;
    reaction_12 = P12*Akt_T308*IRS1_p*AKT3FC                 ;
    reaction_13 = P13*mTORC1_pS2448*TSC1_TSC2_pS1387   ;
    reaction_14 = P14*mTORC1*Amino_Acids*METeff        ;
    reaction_15 = P15 * mTORC2_pS2481                  ;
    reaction_16 = P16*mTORC2*PI3K_variant_p             ;
    reaction_17 = P17 * p70S6K_pT389                 ;
    reaction_18 = P18*p70S6K*mTORC1_pS2448           ;
    reaction_19 = P19 * PRAS40_pS183                  ;
    reaction_20 = P20 * PRAS40_pT246                  ;
    reaction_21 = P21*PRAS40_S183*mTORC1_pS2448        ;
    reaction_22 = P22*PRAS40_T246*Akt_pT308            ;
    reaction_23 = P23*TSC1_TSC2_pT1462*AMPK_pT172       ;
    reaction_24 = P24*TSC1_TSC2_pS1387*Akt_pT308       ;
    reaction_25 = P25 * PI3K_variant_p                 ;
    reaction_26 = P26*PI3K_variant*IR_beta_pY1146       ;
    
    d/dt(Amino_Acids) = 0 ; #Steady input
    d/dt(Insulin) = 0 ;     #Steady input
    d/dt(IR_beta) = (-reaction_1+reaction_3)      ;
    d/dt(IR_beta_pY1146) = (+reaction_1-reaction_2)      ;
    d/dt(IR_beta_refractory) = (+reaction_2-reaction_3)      ;
    d/dt(IRS1) = (-reaction_4+reaction_6)      ;
    d/dt(IRS1_p) = (+reaction_4-reaction_5)      ;
    d/dt(IRS1_pS636) = (+reaction_5-reaction_6)      ;
    d/dt(AMPK) = (-reaction_7+reaction_8)      ;
    d/dt(AMPK_pT172) = (+reaction_7-reaction_8)      ;
    d/dt(Akt_T308) = (+reaction_9-reaction_12)      ;
    d/dt(Akt_pT308) = (-reaction_9+reaction_12)      ;
    d/dt(Akt_S473) = (+reaction_10-reaction_11)      ;
    d/dt(Akt_pS473) = (-reaction_10+reaction_11)      ;
    d/dt(mTORC1) = (+reaction_13-reaction_14)      ;
    d/dt(mTORC1_pS2448) = (-reaction_13+reaction_14)      ;
    d/dt(mTORC2) = (+reaction_15-reaction_16)      ;
    d/dt(mTORC2_pS2481) = (-reaction_15+reaction_16)      ;
    d/dt(p70S6K) = (+reaction_17-reaction_18)      ;
    d/dt(p70S6K_pT389) = (-reaction_17+reaction_18)      ;
    d/dt(PRAS40_T246) = (+reaction_20-reaction_22)      ;
    d/dt(PRAS40_pT246) = (-reaction_20+reaction_22)      ;
    d/dt(PRAS40_S183) = (+reaction_19-reaction_21)      ;
    d/dt(PRAS40_pS183) = (-reaction_19+reaction_21)      ;
    d/dt(TSC1_TSC2_pT1462) = (-reaction_23+reaction_24)      ;
    d/dt(TSC1_TSC2_pS1387) = (+reaction_23-reaction_24)      ;
    d/dt(PI3K_variant) = (+reaction_25-reaction_26)      ;
    d/dt(PI3K_variant_p) = (-reaction_25+reaction_26)      ;
    
    ######## Sud model + additions (IL-1b, kautop)  ########
    
    par1 = ((Tc*(T1/(T1+cT1)))+(w1*T1))/Mi ;
    
    d/dt(Bi) = Bi*A19*(1-(Bi^2/((Bi^2)+(N*Mi)^2))) +
      k2*(N/2)*Mr*(Be/(Be+c9))*k2stim -
      k17*N*Mi*(Bi^2/((Bi^2)+(N*Mi)^2)) -
      k14a*N*Mi*(((Tc+(w3*T1))/Mi)/(((Tc+(w3*T1))/Mi)+c4)) -
      k14b*N*Mi*(Fa/(Fa + f9*I10 + s4b)) -
      k14x*N*Mi*(IL1b/(IL1b + f9*I10 + s4x)) -
      k52*N*Mi*(par1/(par1 + c52)) - Mui*Bi - kautop*Bi*autop;
    
    #Extracellular bacteria (Be)
    d/dt(Be) =  Be*A20 +
      k17*N*Mi*(Bi^2/((Bi^2)+(N*Mi)^2)) - k2*(N/2)*Mr*(Be/(Be+c9))*k2stim +
      k14a*N*Nfracc*Mi*(((Tc+(w3*T1))/Mi)/(((Tc+(w3*T1))/Mi)+c4)) +
      k14b*N*Nfraca*Mi*(Fa/(Fa + f9*I10 + s4b)) +
      k14x*N*Nfraca*Mi*(IL1b/(IL1b + f9*I10 + s4x)) - k15*Ma*Be - k18*Mr*Be +  Mui*Bi ;
    
    Bt = Bi + Be          ;
    
    #Resident macrophage
    d/dt(Mr) = srm + A4a*(Ma+w2*Mi) + sr4b*(Fa/(Fa+(f8*I10)+s4b)) - 
      k2*Mr*(Be/(Be+c9))*k2stim -
      k3*Mr*(Iy/(Iy+(f1*I4)+s1))*((Bt + B*(Fa+IL1b))/(Bt + B*(Fa+IL1b) + c8)) -
      MuMr*Mr ;
    
    #Infected macrophage
    d/dt(Mi) = k2*Mr*(Be/(Be+c9))*k2stim - k17*Mi*(Bi^2/((Bi^2)+(N*Mi)^2)) -
      k14a*Mi*(((Tc+(w3*T1))/Mi)/(((Tc+(w3*T1))/Mi) +c4)) -
      k14b*Mi*(Fa/(Fa+(f9*I10)+s4b)) -
      k14x*Mi*(IL1b/(IL1b+(f9*I10)+s4x)) -
      k52*N*Mi*(par1/(par1 + c52)) -
      MuMi*Mi                   ;
    
    #Activated macrophage
    d/dt(Ma) = k3*Mr*(Iy/(Iy+(f1*I4)+s1))*((Bt + B*(Fa+IL1b))/(Bt + B*(Fa+IL1b) + c8)) -
      k4*Ma*(I10/(I10+s8)) - MuMa*Ma             ;
    
    #Naive T cells
    d/dt(T0) = A1a*(Ma + w2*Mi) + sr1b*(Fa/(Fa + (f8*I10) + s4b2)) +
      A2*T0*(Ma/(Ma+c15)) - k6*I12*T0*(Iy/((Iy*(f1*I4+ f7*I10)) +s1)) -
      k7*T0*(I4/(I4 + f2*Iy + s2)) - MuT0*T0         ;
    
    #Th1 cells (T1)
    d/dt(T1) = A3a*(Ma+w2*Mi) + sr3b*(Fa/(Fa+(f8*I10)+s4b1)) +
      k6*I12*T0*(Iy/((Iy*(f1*I4+ f7*I10)) +s1)) - MuTy*(Iy/(Iy+c))*T1*Ma - MuT1*T1 ;
    
    #Th2 cells (T2)
    d/dt(T2) = A3a2*(Ma+w2*Mi) + sr3b2*(Fa/(Fa+(f8*I10)+s4b1)) + k7*T0*(I4/(I4+(f2*Iy)+s2)) - MuT2*T2 ;
    
    #Precursor activated CD8+ T cells (T80)
    d/dt(T80) = A1a*(Ma+w2*Mi) + sr1b*(Fa/(Fa+(f8*I10)+s4b2)) + A2*T80*(Ma/(Ma+c15)) -
      k6*I12*T80*(Iy/((Iy*(f1*I4+ f7*I10)) +s1)) - MuT80*T80 ;
    
    #Subclass (IFNY producing) of activated CD8+ T cells (T8)
    d/dt(T8) = m*A3ac*(Ma+w2*Mi) + m*sr3bc*(Fa/(Fa+(f8*I10)+s4b1)) +
      m*k6*I12*T80*(Iy/((Iy*(f1*I4+ f7*I10)) +s1)) - MuTcy*(Iy/(Iy+cc))*T8*Ma - MuT8*T8 ;
    
    #Subclass (CTL) of activated CD8+ T cells (Tc)
    d/dt(Tc) = m*A3ac*(Ma+w2*Mi) + m*sr3bc*(Fa/(Fa+(f8*I10)+s4b1)) +
      m*k6*I12*T80*(Iy/((Iy*(f1*I4+ f7*I10)) +s1)) - MuTcy*(Iy/(Iy+cc))*Tc*Ma - MuTc*Tc ;
    
    #TNF-Alpha
    d/dt(Fa) = A30*Mi + A31*Ma*((Iy+(B2*Bt))/(Iy+(B2*Bt)+(f1*I4)+(f7*I10)+s10)) +
      A32*T1 + A33*(Tc+T8) - MuFa*Fa ;
    
    #IFN-Y
    d/dt(Iy) = sg*(Bt/(Bt + c10))*(I12/(I12+s7)) + A5a*T1*(Ma/(Ma+c5b)) +
      A5b*T8*(Ma/(Ma+c5a)) + A7*T0*(I12/(I12+f4*I10+s4)) +
      A7*T80*(I12/(I12 + f4*I10 + s4))  - MuIy*Iy +
      A5c*Mi*(1 - (ImAMPKIy*AMPK_pT172/(I50AMPKIy+AMPK_pT172))) ;
    
    #IL-12
    d/dt(I12) = s12*(Bt /(Bt +c230)) + A23*Mr*(Bt /(Bt +c23)) +
      A8*Ma*(s/(s+I10)) - MuI12*I12 ;
    
    #IL-10
    d/dt(I10) = D7*Ma*(s6/(I10+(f6*Iy)+s6)) + A16*T1 + A17*T2 + A18*(T8+Tc) - MuI10*I10 ;
    
    #IL-4
    d/dt(I4) = A11*T0 + A12*T2 - MuI4*I4 ;
    
    #IL1b
    d/dt(IL1b) = kin1b1*Ma*((Iy+(B2*Bt))/(Iy+(B2*Bt)+f1*I4+(f7*I10)+s10)) - Mu1b*IL1b ;
    
    Btlog10 = log10(Bt) ; 
})
