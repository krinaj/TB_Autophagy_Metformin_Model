source("code_pd.R")

ev <- et(timeUnits="days") %>%
 # et(amt=500, time=0, dosing.to="metdepot", addl=180*2, ii=0.5) %>% #metformin
  add.sampling(seq(0,360,1))

params2 <- params %>% distinct(., .keep_all=TRUE) %>%
  tidyr::spread(Parameter, Value)

# params3 <- merge(mytime, params2) %>%
#   select(time=x, everything()) 
# 
# params4 <- full_join(ev, params3) %>% select(-cmt) %>% 
#   group_by(id, time, desc(evid)) %>%
#   slice(1) %>% ungroup() 
# 
# params5 <- params4

inits <- c(
  Be=100,
  Mr=400000,
  Ma=1e-1,
  Mi=1e-1,
  T0=8000,
  IR_beta = 16.5607,
  IRS1 = 18.9345,
  AMPK = 20.5064,
  Akt_T308 = 21.4109,
  Akt_S473 = 12.2517,
  mTORC1 = 25.14,
  mTORC2 = 18.7959,
  p70S6K = 14.301,
  PRAS40_T246 = 13.5613,
  PRAS40_S183 = 17.55,
  TSC1_TSC2_pT1462 = 14.9175,
  PI3K_variant = 18.9345,
  Amino_Acids = 10, 
  Insulin = 10)

sim1 <- rxSolve(mod, params=params2, inits=inits, ev=ev,
                returnType="data.frame", atol=tol, rtol=tol)

sim1$time <- units::drop_units(sim1$time)

data.table::fwrite(sim1, "Outputs/withoutMET.csv", row.names = F, na=".")
