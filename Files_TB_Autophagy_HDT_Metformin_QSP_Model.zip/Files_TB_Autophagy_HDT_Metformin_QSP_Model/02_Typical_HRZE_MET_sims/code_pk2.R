mod <- RxODE({
  #Rifampin PK (Svensson 2018, PMID:28653479)
  enzRIF(0) = 1 ;
  VmaxRIF = VmaxRIF*(WT/70)^0.75 ;
  VRIF = VRIF*(WT/70) ;
  BIO = 1*(1 + (FMAXRIF*(DOSERIF-450))/(ED50RIF+(DOSERIF-450))) ;
  d/dt(depotRIF) = transit(NNRIF,MTTRIF,BIO) - kaRIF*depotRIF  ;
  d/dt(centRIF) = kaRIF*depotRIF - ((VmaxRIF/(KmRIF+(centRIF/VRIF)))/VRIF)*centRIF*enzRIF  ;
  d/dt(enzRIF) = KENZRIF*(1 + (EmIRIF*(centRIF/VRIF))/(EC50IRIF + (centRIF/VRIF))) - KENZRIF*enzRIF  ;
  CpRIF = centRIF/VRIF ;
  CinRIF = CpRIF*ACRIF ;
  CexRIF = CpRIF*ELFRIF ;
  CnliR =  CinRIF ;
  CnlR = CexRIF ;
  
  #Isoniazid PK (Denti 2015, PMID:26501782)
  if(ACEStatus==0) {CLINH=CLRINH ;} else {CLINH=CLSINH ;}
  CLINH = CLINH*(WT/51.9)^0.75 ;
  QINH = QINH*(WT/51.9)^0.75 ;
  VINH = VINH*(WT/51.9)   ;
  V2INH = V2INH*(WT/51.9) ;
  d/dt(depotINH) = -transit(NNINH,MTTINH,1) ;
  d/dt(centINH) = transit(NNINH,MTTINH,1) - (CLINH/VINH)*centINH - (QINH/VINH)*centINH + (QINH/V2INH)*periINH ;
  d/dt(periINH) = (QINH/VINH)*centINH - (QINH/V2INH)*periINH ;
  CpINH = centINH/VINH ;
  CinINH = CpINH*ACINH ;
  CexINH = CpINH*ELFINH ;
  CnliI =  CinINH  ;
  CnlI = CexINH    ; 
  
  
  #Pyrazinamide PK (Denti 2015, PMID:26501782)
  CLPYZ = CLPYZ*(WT/51.9)^0.75 ;
  VPYZ = VPYZ*(WT/51.9)   ;
  d/dt(depotPYZ) = -transit(NNPYZ,MTTPYZ,1) ;
  d/dt(centPYZ) = transit(NNPYZ,MTTPYZ,1) - (CLPYZ/VPYZ)*centPYZ ;
  CpPYZ = centPYZ/VPYZ ;
  CinPYZ = CpPYZ*ACPYZ ;
  CexPYZ = CpPYZ*ELFPYZ ;
  CnliP = CinPYZ ;
  CnlP = CexPYZ  ;
  
  #Ethambutol PK (Denti 2015, PMID:26501782)
  CLETH = CLETH*(WT/51.9)^0.75 ;
  QETH = QETH*(WT/51.9)^0.75 ;
  VETH = VETH*(WT/51.9)   ;
  V2ETH = V2ETH*(WT/51.9) ;
  d/dt(depotETH) = -transit(NNETH,MTTETH,1) ;
  d/dt(centETH) = transit(NNETH,MTTETH,1) - (CLETH/VETH)*centETH - (QETH/VETH)*centETH + (QETH/V2ETH)*periETH ;
  d/dt(periETH) = (QETH/VETH)*centETH - (QETH/V2ETH)*periETH ;
  CpETH = centETH/VETH ;
  CinETH = CpETH*ACETH ;
  CexETH = CpETH*ELFETH ;
  CnliE = CinETH ;
  CnlE = CexETH  ;
  
 if(t<2*24){
    kmaxeR = kmaxeR1 ;
    kmaxeI = kmaxeI1 ;
    kmaxeP = kmaxeP1 ;
    kmaxeE = kmaxeE1 ;
    kmaxiR = kmaxiR1 ;
    kmaxiI = kmaxiI1 ;
    kmaxiP = kmaxiP1 ;
   kmaxiE = kmaxiE1 ;
  } else {
    if(t>15*24){
      kmaxeR = kmaxeR15 ;
      kmaxeI = kmaxeI15 ;
    kmaxeP = kmaxeP15 ;
  kmaxeE = kmaxeE15 ;
  kmaxiR = kmaxiR15 ;
  kmaxiI = kmaxiI15 ;
   kmaxiP = kmaxiP15 ;
    kmaxiE = kmaxiE15 ;
   } else
   {
      kmaxeR = kmaxeR2 ;
      kmaxeI = kmaxeI2 ;
      kmaxeP = kmaxeP2 ;
      kmaxeE = kmaxeE2 ;
      kmaxiR = kmaxiR2 ;
      kmaxiI = kmaxiI2 ;
      kmaxiP = kmaxiP2 ;
      kmaxiE = kmaxiE2 ;
     }
   }
  

  #Extracellular Mtb bacteria
  if(CnlR > EC50R1){
    statR = 1 
  } else {statR = (1- (1/(1 + (EC50R1/CnlR)^GR1)))}

  if(CnlI > EC50I1){
    statI = 1 
  } else {statI = (1- (1/(1 + (EC50I1/CnlI)^GI1)))}

  if(CnlP > EC50P1){
    statP = 1 
  } else {statP = (1- (1/(1 + (EC50P1/CnlP)^GP1)))}

  if(CnlE > EC50E1){
    statE = 1 
  } else {statE = (1- (1/(1 + (EC50E1/CnlE)^GE1)))}

  killR = kmaxeR*(1/(1+(EC50R/CnlR)^GR)) ;
  killI = kmaxeI*(1/(1+(EC50I/CnlI)^GI)) ;
  killP = kmaxeP*(1/(1+(EC50P/CnlP)^GP)) ;
  killE = kmaxeE*(1/(1+(EC50E/CnlE)^GE)) ;
  
  if(CnliR > EC50R1){
    statiR = 1
} else {statiR = (1- (1/(1 + (EC50R1/CnliR)^GR1)))}

  if(CnliI > EC50I1){
    statiI = 1 
  } else {statiI = (1- (1/(1 + (EC50I1/CnliI)^GI1)))}
  
  if(CnliP > EC50P1){
    statiP = 1 
  } else {statiP = (1- (1/(1 + (EC50P1/CnliP)^GP1)))}
  
  if(CnliE > EC50E1){
    statiE = 1 
  } else {statiE = (1- (1/(1 + (EC50E1/CnliE)^GE1)))}

  killiR = kmaxiR*(1/(1+(EC50R/CnliR)^GR)) ;
  killiI = kmaxiI*(1/(1+(EC50I/CnliI)^GI)) ;
  killiP = kmaxiP*(1/(1+(EC50P/CnliP)^GP)) ;
  killiE = kmaxiE*(1/(1+(EC50E/CnliE)^GE)) ;

  
})
