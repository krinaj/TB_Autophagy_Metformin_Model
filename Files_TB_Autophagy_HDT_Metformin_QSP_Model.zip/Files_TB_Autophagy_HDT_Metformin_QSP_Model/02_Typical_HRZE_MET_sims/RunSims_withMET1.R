source("code_pk2.R")

ev <- et(timeUnits="hours") %>%
  et(amt=1e-6, time=0, dosing.to="depotRIF", addl=180, ii=24) %>% #dummy
  et(amt=1e-6, time=0, dosing.to="depotINH", addl=180, ii=24) %>% #dummy
  et(amt=1e-6, time=0, dosing.to="depotPYZ", addl=180, ii=24) %>% #dummy
  et(amt=1e-6, time=0, dosing.to="depotETH", addl=180, ii=24) %>% #dummy
  et(amt=600, time=180*24, dosing.to="depotRIF", addl=180, ii=24) %>% #Rifampicin
  et(amt=300, time=180*24, dosing.to="depotINH", addl=180, ii=24) %>% #Isoniazid
  et(amt=1500, time=180*24, dosing.to="depotPYZ", addl=62, ii=24) %>% #Pyrazinamide
  et(amt=1100, time=180*24, dosing.to="depotETH", addl=62, ii=24) %>% #Ethambutol
  add.sampling(seq(0,360*24,1)) 

pk  <- rxSolve(mod,ev,inits=NULL,params=params1)

pk <- pk %>% select(time, CnlR, CnlI, CnlP, CnlE,
              CnliR, CnliI, CnliP, CnliE,
              statR, statI,statP,statE,killR,killI,killP,killE,
              statiR, statiI,statiP,statiE,killiR,killiI,killiP,killiE)

pk$time <- units::drop_units(pk$time)

pk <- pk %>% tidyr::gather(c("statR","statI","statP","statE",
                                "killR","killI","killP","killE",
                                "statiR","statiI","statiP","statiE",
                                "killiR","killiI","killiP","killiE"),
                              key="key",value="value") 
pksum <- pk %>% 
  mutate(Day=ceiling(time/24)) %>%
  select(-time) %>%
  group_by(Day, key) %>%
  summarize(MValue = median(value, na.rm=T)) %>%
  ungroup() 

pdinput <- pksum %>% 
  mutate(MValue=ifelse(grepl("kill", key), ifelse(MValue<=1e-8,0, MValue), MValue)) %>% 
  mutate(MValue=ifelse(grepl("stat", key), ifelse(MValue<=1e-8, 1, MValue), MValue)) %>% 
  group_by(Day) %>%
  tidyr::spread(key, MValue) %>%
  ungroup() %>%
  select(Day, everything()) %>%
  arrange(Day)

source("code_pd.R")

ev <- et(timeUnits="days") %>%
  et(amt=250, time=180, dosing.to="metdepot", addl=180*2, ii=0.5) %>% #metformin
  add.sampling(seq(0,359,1))

ev$killiE <- pdinput$killiE
ev$killiP <- pdinput$killiP
ev$killiI <- pdinput$killiI
ev$killiR <- pdinput$killiR
ev$statiE <- pdinput$statiE
ev$statiP <- pdinput$statiP
ev$statiI <- pdinput$statiI
ev$statiR <- pdinput$statiR
ev$killE <- pdinput$killE
ev$killP <- pdinput$killP
ev$killI <- pdinput$killI
ev$killR <- pdinput$killR
ev$statE <- pdinput$statE
ev$statP <- pdinput$statP
ev$statI <- pdinput$statI
ev$statR <- pdinput$statR

params2 <- params %>% distinct(., .keep_all=TRUE) %>%
  tidyr::spread(Parameter, Value)

mytime <- ev$time

params3 <- merge(mytime, params2) %>%
  select(time=x, everything()) 

params4 <- full_join(ev, params3) %>% select(-cmt) %>% 
  group_by(id, time, desc(evid)) %>%
  slice(1) %>% ungroup() 

params5 <- params4

inits <- c(
  Be=100,
  Mr=400000,
  Ma=1e-1,
  Mi=1e-1,
  T0=8000,
  IR_beta = 16.5607,
  IRS1 = 18.9345,
  AMPK = 20.5064,
  Akt_T308 = 21.4109,
  Akt_S473 = 12.2517,
  mTORC1 = 25.14,
  mTORC2 = 18.7959,
  p70S6K = 14.301,
  PRAS40_T246 = 13.5613,
  PRAS40_S183 = 17.55,
  TSC1_TSC2_pT1462 = 14.9175,
  PI3K_variant = 18.9345,
  Amino_Acids = 10, 
  Insulin = 10)

sim1 <- rxSolve(mod, params=params5, inits=inits, 
                returnType="data.frame", atol=tol, rtol=tol)

sim1$time <- units::drop_units(sim1$time)

data.table::fwrite(sim1, "Outputs/withMET250.csv", row.names = F, na=".")
